<?PHP

require_once('modules/ImportTemplates/ImportTemplates_sugar.php');
class ImportTemplates extends ImportTemplates_sugar {
	
	function ImportTemplates(){
		parent::ImportTemplates_sugar();
	}

    public function save()
    {
        return parent::save();
    }

}
?>