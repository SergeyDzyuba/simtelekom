<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_PS_EMPL_NOTES_FROM_NOTES_TITLE'] = 'Сканы';
$mod_strings['LBL_PS_EMPL_PS_DOCS_FROM_PS_DOCS_TITLE'] = 'Наличие документов';
$mod_strings['LBL_PS_EMPL_PS_SKILLS_FROM_PS_SKILLS_TITLE'] = 'Навыки';
$mod_strings['LBL_PS_EMPL_PS_VACATION_FROM_PS_VACATION_TITLE'] = 'Планирование отпусков';
