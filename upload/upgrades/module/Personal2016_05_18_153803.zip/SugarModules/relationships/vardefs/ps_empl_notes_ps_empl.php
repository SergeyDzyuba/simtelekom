<?php
// created: 2016-05-18 15:38:03
$dictionary["ps_empl"]["fields"]["ps_empl_notes"] = array (
  'name' => 'ps_empl_notes',
  'type' => 'link',
  'relationship' => 'ps_empl_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_PS_EMPL_NOTES_FROM_NOTES_TITLE',
);
