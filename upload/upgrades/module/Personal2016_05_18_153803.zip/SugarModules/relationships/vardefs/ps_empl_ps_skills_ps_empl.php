<?php
// created: 2016-05-18 15:38:03
$dictionary["ps_empl"]["fields"]["ps_empl_ps_skills"] = array (
  'name' => 'ps_empl_ps_skills',
  'type' => 'link',
  'relationship' => 'ps_empl_ps_skills',
  'source' => 'non-db',
  'module' => 'ps_skills',
  'bean_name' => 'ps_skills',
  'side' => 'right',
  'vname' => 'LBL_PS_EMPL_PS_SKILLS_FROM_PS_SKILLS_TITLE',
);
