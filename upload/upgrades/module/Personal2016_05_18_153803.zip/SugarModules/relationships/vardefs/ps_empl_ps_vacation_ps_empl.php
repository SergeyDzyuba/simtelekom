<?php
// created: 2016-05-18 15:38:03
$dictionary["ps_empl"]["fields"]["ps_empl_ps_vacation"] = array (
  'name' => 'ps_empl_ps_vacation',
  'type' => 'link',
  'relationship' => 'ps_empl_ps_vacation',
  'source' => 'non-db',
  'module' => 'ps_vacation',
  'bean_name' => 'ps_vacation',
  'side' => 'right',
  'vname' => 'LBL_PS_EMPL_PS_VACATION_FROM_PS_VACATION_TITLE',
);
