<?php
// created: 2016-04-07 16:05:00
$dictionary["CCU_Agents"]["fields"]["ccu_agents_ccu_agent_doc"] = array (
  'name' => 'ccu_agents_ccu_agent_doc',
  'type' => 'link',
  'relationship' => 'ccu_agents_ccu_agent_doc',
  'source' => 'non-db',
  'module' => 'CCU_Agent_doc',
  'bean_name' => 'CCU_Agent_doc',
  'side' => 'right',
  'vname' => 'LBL_CCU_AGENTS_CCU_AGENT_DOC_FROM_CCU_AGENT_DOC_TITLE',
);
