<?php
// created: 2016-04-07 15:59:48
$dictionary["CCU_Agents"]["fields"]["ccu_agents_tasks"] = array (
  'name' => 'ccu_agents_tasks',
  'type' => 'link',
  'relationship' => 'ccu_agents_tasks',
  'source' => 'non-db',
  'module' => 'Tasks',
  'bean_name' => 'Task',
  'side' => 'right',
  'vname' => 'LBL_CCU_AGENTS_TASKS_FROM_TASKS_TITLE',
);
