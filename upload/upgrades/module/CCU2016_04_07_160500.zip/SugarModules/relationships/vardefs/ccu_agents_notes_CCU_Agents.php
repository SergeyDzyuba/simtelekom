<?php
// created: 2016-04-07 16:05:00
$dictionary["CCU_Agents"]["fields"]["ccu_agents_notes"] = array (
  'name' => 'ccu_agents_notes',
  'type' => 'link',
  'relationship' => 'ccu_agents_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_CCU_AGENTS_NOTES_FROM_NOTES_TITLE',
);
