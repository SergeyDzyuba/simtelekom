<?php
 // created: 2016-04-26 16:56:09
$layout_defs["CCU2_Agents31"]["subpanel_setup"]['ccu2_agents3_ccu2_agent_docs1'] = array (
  'order' => 100,
  'module' => 'CCU2_agent_docs1',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_CCU2_AGENTS3_CCU2_AGENT_DOCS1_FROM_CCU2_AGENT_DOCS1_TITLE',
  'get_subpanel_data' => 'ccu2_agents3_ccu2_agent_docs1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
