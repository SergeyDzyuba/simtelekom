<?php
// created: 2016-04-26 16:56:09
$dictionary["CCU2_Agents3"]["fields"]["ccu2_agents3_ccu2_agent_docs1"] = array (
  'name' => 'ccu2_agents3_ccu2_agent_docs1',
  'type' => 'link',
  'relationship' => 'ccu2_agents3_ccu2_agent_docs1',
  'source' => 'non-db',
  'module' => 'CCU2_agent_docs1',
  'bean_name' => 'CCU2_agent_docs1',
  'side' => 'right',
  'vname' => 'LBL_CCU2_AGENTS3_CCU2_AGENT_DOCS1_FROM_CCU2_AGENT_DOCS1_TITLE',
);
