<?php
// created: 2016-04-26 16:56:09
$dictionary["CCU2_Agents31"]["fields"]["ccu2_agents3_ccu2_logins1"] = array (
  'name' => 'ccu2_agents3_ccu2_logins1',
  'type' => 'link',
  'relationship' => 'ccu2_agents3_ccu2_logins1',
  'source' => 'non-db',
  'module' => 'CCU2_Logins1',
  'bean_name' => 'CCU2_Logins1',
  'side' => 'right',
  'vname' => 'LBL_CCU2_AGENTS3_CCU2_LOGINS1_FROM_CCU2_LOGINS1_TITLE',
);
