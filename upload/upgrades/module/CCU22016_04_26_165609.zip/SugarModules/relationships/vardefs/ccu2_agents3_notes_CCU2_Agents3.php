<?php
// created: 2016-04-26 16:56:09
$dictionary["CCU2_Agents3"]["fields"]["ccu2_agents3_notes"] = array (
  'name' => 'ccu2_agents3_notes',
  'type' => 'link',
  'relationship' => 'ccu2_agents3_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_CCU2_AGENTS3_NOTES_FROM_NOTES_TITLE',
);
