<?php
// created: 2016-04-26 16:56:09
$dictionary["CCU2_Agents3"]["fields"]["ccu2_logins_ccu2_agents3"] = array (
  'name' => 'ccu2_logins_ccu2_agents3',
  'type' => 'link',
  'relationship' => 'ccu2_logins_ccu2_agents3',
  'source' => 'non-db',
  'module' => 'CCU2_Logins1',
  'bean_name' => 'CCU2_Logins1',
  'side' => 'right',
  'vname' => 'LBL_CCU2_LOGINS_CCU2_AGENTS3_FROM_CCU2_LOGINS1_TITLE',
);
