<?php
// created: 2016-04-26 16:33:31
$dictionary["CCU2_Agents3"]["fields"]["ccu2_agent_docs_ccu2_agents3"] = array (
  'name' => 'ccu2_agent_docs_ccu2_agents3',
  'type' => 'link',
  'relationship' => 'ccu2_agent_docs_ccu2_agents3',
  'source' => 'non-db',
  'module' => 'CCU2_agent_docs',
  'bean_name' => 'CCU2_agent_docs',
  'side' => 'right',
  'vname' => 'LBL_CCU2_AGENT_DOCS_CCU2_AGENTS3_FROM_CCU2_AGENT_DOCS_TITLE',
);
