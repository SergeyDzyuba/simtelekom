<?php
// created: 2016-04-12 15:18:54
$dictionary["CCU2_Agents2"]["fields"]["ccu2_agents2_notes"] = array (
  'name' => 'ccu2_agents2_notes',
  'type' => 'link',
  'relationship' => 'ccu2_agents2_notes',
  'source' => 'non-db',
  'module' => 'Notes',
  'bean_name' => 'Note',
  'side' => 'right',
  'vname' => 'LBL_CCU2_AGENTS2_NOTES_FROM_NOTES_TITLE',
);
